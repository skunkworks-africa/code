import  Octokit  from "octokit";
const octokit = new Octokit({ 
  auth: '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'
});
await octokit.request("POST /repos/{owner}/{repo}/issues", {
  owner: "octocat",
  repo: "Spoon-Knife",
  title: "Created with the REST API",
  body: "This is a test issue created by the REST API",
});
