const filterapiSource = "https://jsonplaceholder.typicode.com/users"; // replace with actual remote json source
const check = document.getElementById("apt").checked; //boolean for apt checkbox data

const label=document.querySelector('label[for="apt"]')
//var checkval='';
const display =document.querySelector("#display-data");
const input = document.querySelector('#input'); //input data
//const apt =document.queryselector('#apt');
var qm ='"';

//label.addEventListener('click', () => {
 //check = !check;
//});
console.log(check);
//console.log(filtarr)
const getrawData = async () => {
    const res = await fetch(filterapiSource); //works on server but not on local file
    const data = await  res.json();
    return data
}





const cvalidate=()=>{
  var check = document.getElementById("apt").checked;
  if (check){checkval="c"}
  else {checkval=""}
return checkval
}
document.getElementById('apt').addEventListener('change',cvalidate,false)


apt.addEventListener("change",()=>{
 cvalidate();
})

const filt1=cvalidate()
console.log(filt1);

async function filterList1() { 
  
    let query = filt1; //input var
    //filter added between payload and etc because payload holds users list
    const payload = await getrawData();
    //seperates arrays in json into seperate objects
    //error on line 34 suite not recognized appropriately//suite will be changed to appropriate json parameter
    let filterList = payload.filter((eventData) => {
        if (query === "") { return eventData; }
        else if (eventData.name.toLowerCase().includes(query)) { return eventData}   
    });

     
     return filterList
    }
    
filterList1();
apt.addEventListener("change",()=>{
filterList1();
});





const filtlist =filterList1();

console.log(filtlist);

//console.log(filtered);


const displayUsers = () => {
  let query = input.value;//input var
  console.log("Query:",query)
  const payload =filtlist;  //filter added between payload and etc because payload holds users list
    console.log(payload);
    //seperates arrays in json into seperate objects
    let dataDisplay = payload.filter((eventData)=>{
        if (query==="") {return eventData}
        else if (eventData.name.toLowerCase().includes(query.toLowerCase())){return  eventData}
    }).map((object) => {
  
       const {title, username} = object; // replace with appropriate paramaters in official file

       return `
        <div class="container">
         <p>Name:${title}</p>
         <p>Username:${username}</p>
         </div>
         <hr>
       `
              
    }).join("");

    display.innerHTML = dataDisplay;
    console.log(dataDisplay);

}
displayUsers();
input.addEventListener("input",()=>{
displayUsers();
})