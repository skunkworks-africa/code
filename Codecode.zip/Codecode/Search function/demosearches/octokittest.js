

//const result = await octokit.request("GET /repos/{owner}/{repo}/issues", {
  //  owner: "REPO-OWNER",
   // repo: "REPO-NAME",
   // per_page: 2,
  //});

 
 // const { Octokit, App } = require("octokit");
import { Octokit } from "/octokit";
//import { Octokit, App } from "https://esm.sh/octokit";
//import { Octokit,App } from "octokit" ; 
//import { Octokit, App } from "octokit";
    const octokit = new Octokit({ 
    auth: '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'
  });

  const getrawData = async () => {


   

    const res = await  octokit.request("GET /octocat", {
        headers: {
          "content-type": "text/plain",
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      
    const data = await  res.json();
    return data
}
  
  console.log( getrawData())
  