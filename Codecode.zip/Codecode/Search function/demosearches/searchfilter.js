const filterapiSource = "https://jsonplaceholder.typicode.com/users"; // replace with actual remote json source
var check = document.getElementById("apt").checked; //boolean for apt checkbox data
const filtarr=[];
const label=document.querySelector('label[for="apt"]')
//var checkval='';
const display =document.querySelector("#display-data");
const input = document.querySelector('#input'); //input data


console.log(check);

const getrawData = async () => {
    const res = await fetch(filterapiSource); //works on server but not on local file
    const data = await  res.json();
    return data
}



const cvalidate=()=>{
  var check = document.getElementById("apt").checked;
  if (check){checkval="c"}
  else {checkval=""}
return checkval
}
document.getElementById('apt').addEventListener('change',cvalidate,false)


apt.addEventListener("change",()=>{
 cvalidate();
})

const filt1=cvalidate()
console.log(filt1);

async function filterList1() { 
  const filtarr=[];
    let query = filt1; //input var
    //filter added between payload and etc because payload holds users list
    const payload = await getrawData();
    //seperates arrays in json into seperate objects
    //error on line 34 suite not recognized appropriately//suite will be changed to appropriate json parameter
    let filterList = payload.filter((eventData) => {
        if (query === "") { return eventData; }
        else if (eventData.name.toLowerCase().includes(query.toLowercase())) { return eventData}   
    }).map((object) => {
  
        const {name, username} = object;
 
        return `
         <div class="container">
          <p>Name:${name}</p>
          <p>Username:${username}</p>
          </div>
          <hr>
        `
               
     }).join("");
 
     display.innerHTML = dataDisplay;
     //filtarr.push(filterList);
     //return filtarr
    }
    
filterList1();
apt.addEventListener("change",()=>{
filterList1();
});
const filtlist =filterList1();