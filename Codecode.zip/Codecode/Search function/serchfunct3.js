
const Coursefeed = "https://jsonplaceholder.typicode.com/users"; // replace with actual remote json source
const display =document.querySelector("#display-data");
const input = document.querySelector('#input'); //input data


const getData = async () => {
    const res = await fetch(Coursefeed); //works on server but not on local file
    const data = await  res.json();
    return data
}

const verseoune =getData();
console.log(verseoune);
const displayUsers =async () => {
          let query = input.value;//input var
        console.log("Query::",query);


        //filter added between payload and etc because payload holds users list
    const payload = await getData();
    //seperates arrays in json into seperate objects
    let dataDisplay = payload.filter((eventData)=>{
        if (query==="") {return eventData}
        else if (eventData.name.toLowerCase().includes(query.toLowerCase())){return eventData}
    }).map((object) => {
  
       const {name, username} = object;

       return `
        <div class="container">
         <p>Name:${name}</p>
         <p>Username:${username}</p>
         </div>
         <hr>
       `
              
    }).join("");

    display.innerHTML = dataDisplay;
}
displayUsers();

input.addEventListener("input",()=>{
displayUsers();
})