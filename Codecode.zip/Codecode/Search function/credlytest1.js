const filterapiSource = "https://sandbox-api.credly.com/v1/org/ibm/badge/ibm-spss-modeler-foundations-v18-2-code-0a069g"; // replace with actual remote json source
const label=document.querySelector('label[for="apt"]')
const display =document.querySelector("#display-data");
const input = document.querySelector('#input'); //input data
const apt =document.getElementById('apt');
const check = document.getElementById("apt").checked;
//console.log(check);
const getrawData = async () => {
    const res = await fetch(filterapiSource); //works on server but not on local file
    const data = await  res.json();
    return data
}



const cvalidate=()=>{
   var check = document.getElementById("apt").checked;

    //var checkval=String
     if (check){checkval="cl"}
     else {checkval=""}
     console.log(checkval)

return checkval
}

const e="le"

async function filterList1() { 
    const check = document.getElementById("apt").checked;
   const checkval=(check===true)?"le":""
    console.log(checkval)

    let query=(check===true)?`${e}`:"";
     console.log("Filtquery:",query);
    const payload = await getrawData();
    //seperates arrays in json into seperate objects
   //filters will be tweaked to suit ideal parameters
    let filterList = payload.filter((eventData) => {
        if (query === "") { return eventData; }
        else if (eventData.name.toLowerCase().includes(query)) { return eventData}   
    }).map((object) => {

        const {name, username} = object;
       
        return `
         <div class="container">
          <p>Name:${name}</p>
          <p>Username:${username}</p>
          </div>
          <hr>
        `
               
       }).join("");
       ;

     
       display.innerHTML = filterList;
    }
    
    
filterList1();
//filterList1("apt","le",name,filterapiSource);
apt.addEventListener("change",filterList1);


const filtlist =filterList1();
console.log(filtlist);



