const filterapiSource = "https://jsonplaceholder.typicode.com/users"; // replace with actual remote json source
const label=document.querySelector('label[for="apt"]')
const display =document.querySelector("#display-data");
const input = document.querySelector('#input'); //input data
const apt =document.getElementById('apt');
const check = document.getElementById("apt").checked;
//console.log(check);
const getrawData = async () => {
    const res = await fetch(filterapiSource); //works on server but not on local file
    const data = await  res.json();
    return data
}



const cvalidate=()=>{
   var check = document.getElementById("apt").checked;

    //var checkval=String
     if (check){checkval="cl"}
     else {checkval=""}
     console.log(checkval)

return checkval
}

//cvalidate();
//apt.addEventListener("change",cvalidate)



//console.log(cvalidate());
//const filt1=cvalidate()+"";
//console.log(filt1);
//console.log(typeof cvalidate())

async function filterList1() { 
    const check = document.getElementById("apt").checked;
   const checkval=(check===true)?`le`:""
    console.log(checkval)
   // const filt2=checkval

  //var gate="le";
    //let query =checkval;//cvalidate(); //input var
  
    //filter added between payload and etc because payload holds users list
    let query=(check===true)?"le":"";
     console.log("Filtquery:",query);
    const payload = await getrawData();
    //seperates arrays in json into seperate objects
   //filters will be tweaked to suit ideal parameters
    let filterList = payload.filter((eventData) => {
        if (query==null) { return eventData; }
        else if (eventData.name.toLowerCase().includes(query.toLowerCase())) { return eventData}   
    });

     
     return filterList
    }
    
filterList1();
apt.addEventListener("change",filterList1);


const filtlist =filterList1();
console.log(filtlist);



const displayUsers =async () => {
    let query = input.value;//input var
  console.log("Query::",query);
  //filter added between payload and etc because payload holds users list
const payload = await filtlist;
//seperates arrays in json into seperate objects
let dataDisplay = payload.filter((eventData)=>{
  if (query==="") {return eventData}
  else if (eventData.name.toLowerCase().includes(query.toLowerCase()) ){return eventData}
  else if (eventData.username.toLowerCase().includes(query.toLowerCase())){return eventData}
}).map((object) => {

 const {name, username} = object;

 return `
  <div class="container">
   <p>Name:${name}</p>
   <p>Username:${username}</p>
   </div>
   <hr>
 `
        
}).join("");

display.innerHTML = dataDisplay;
}
displayUsers();




//const printusers=async()=>{}
input.addEventListener("input",()=>{
displayUsers();
})