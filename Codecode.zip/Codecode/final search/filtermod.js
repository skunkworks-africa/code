

export default async function mFilt(hId,Key,jSource) { 
    const check = hId.checked;

    let query=(check===true)?`${Key}`:"";
     console.log("Filtquery:",query);
    const payload = await jSource;
    //seperates arrays in json into seperate objects
   //filters will be tweaked to suit ideal parameters
    let filterList = payload.filter((eventData) => {
        if (query === "") { return eventData; }
        else if (eventData.MKTCATEGORY_NAME.toLowerCase().includes(query)) { return eventData}   
    })
    return filterList;
    }



  export  async function sFilt(hId,Key,jSource) { 
        const check = hId.checked;

        let query=(check===true)?`${Key}`:"";
         console.log("Filtquery:",query);
        const payload = await jSource;
        //seperates arrays in json into seperate objects
       //filters will be tweaked to suit ideal parameters
        let filterList = payload.filter((eventData) => {
            if (query === "") { return eventData; }
            else if (eventData.SKILLLEVEL.toLowerCase().includes(query)) { return eventData}   
        })
        return filterList;
        }


 export   async function jFilt(hId,Key,jSource) { 
            const check = hId.checked;
        
            let query=(check===true)?`${Key}`:"";
             console.log("Filtquery:",query);
            const payload = await jSource;
            //seperates arrays in json into seperate objects
           //filters will be tweaked to suit ideal parameters
            let filterList = payload.filter((eventData) => {
                if (query === "") { return eventData; }
                else if (eventData.JOB_ROLE.toLowerCase().includes(query)) { return eventData}   
            })
            return filterList;
            }